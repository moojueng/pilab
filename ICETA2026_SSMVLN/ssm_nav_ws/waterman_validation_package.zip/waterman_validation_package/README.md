# Waterman revised validation package

## 목적
기존 미지환경/SSM 실험 대신, **맵이 있는 환경에서 A\* 경로계획**을 검증하고, 교수님 피드백에 맞춰 **VLM 이상감지 4-class 평가**를 수행하기 위한 패키지입니다.

## 포함 파일
- `maps/grid_unseen/`: A\* 검증용 unseen grid map 20개
- `outputs/astar_success_images/`: A\* 성공 경로 이미지 20개
- `outputs/metrics/astar_unseen_metrics.csv`: map별 A\* 성능지표
- `outputs/metrics/astar_summary.json`: A\* 요약 성능지표
- `outputs/metrics/astar_moves_bar.png`: map별 이동 step 그래프
- `scripts/run_astar_validation.py`: A\* 재검증 및 이미지 재생성 스크립트
- `scripts/eval_anomaly_multiclass.py`: VLM 4-class 성능평가 스크립트
- `vlm_eval/anomaly_eval_input_template.csv`: VLM 평가 입력 템플릿

## A\* 검증 결과 요약
- map 수: 20
- 성공 수: 20
- 성공률: 100.0%
- 평균 이동 step: 14.30
- 최소/최대 이동 step: 3 / 23
- 평균 확장 노드 수: 31.50

## 직접 재검증 방법
```bash
cd waterman_validation_package
python scripts/run_astar_validation.py
```

## VLM 이상감지 평가 방법
class는 `normal`, `micro_crack`, `crack`, `leakage` 4개입니다.
위험도 변환은 `normal→normal`, `micro_crack→high`, `crack/leakage→critical`입니다.

1. `vlm_eval/anomaly_eval_input_template.csv`를 복사해서 `vlm_eval/anomaly_eval_input.csv`로 이름을 바꿉니다.
2. 각 이미지별 정답과 VLM 예측값을 입력합니다.
3. 실행합니다.
```bash
python scripts/eval_anomaly_multiclass.py
```

생성 결과:
- `outputs/metrics/vlm_classification_metrics.json`
- `outputs/metrics/vlm_per_class_metrics.csv`

## 보고서용 문장
맵 정보가 주어진 환경에서 A\* 알고리즘을 적용한 결과, unseen grid map 20개 모두에서 목표 지점까지 경로 탐색에 성공하였다. 평균 이동 step은 14.30로 나타났으며, 이는 맵 기반 점검 환경에서 A\*가 효율적인 경로 생성 방법임을 보여준다. 이상감지는 기존 binary 방식에서 normal, micro_crack, crack, leakage의 4-class 분류로 확장하여 class별 precision, recall, F1-score 및 confusion matrix를 산출하도록 수정하였다.
