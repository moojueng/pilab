import csv, json
from pathlib import Path
CLASSES=['normal','micro_crack','crack','leakage']
RISK_MAP={'normal':'normal','micro_crack':'high','crack':'critical','leakage':'critical'}
RISKS=['normal','high','critical']
def matrix(y_true,y_pred,labels):
    idx={v:i for i,v in enumerate(labels)}; m=[[0 for _ in labels] for _ in labels]
    for t,p in zip(y_true,y_pred): m[idx[t]][idx[p]]+=1
    return m
def report(y_true,y_pred,labels):
    m=matrix(y_true,y_pred,labels); total=sum(map(sum,m)); correct=sum(m[i][i] for i in range(len(labels))); per=[]; macro=[]; weighted=0
    for i,label in enumerate(labels):
        tp=m[i][i]; fp=sum(m[r][i] for r in range(len(labels)) if r!=i); fn=sum(m[i][c] for c in range(len(labels)) if c!=i); support=sum(m[i])
        precision=tp/(tp+fp) if tp+fp else 0.0; recall=tp/(tp+fn) if tp+fn else 0.0; f1=2*precision*recall/(precision+recall) if precision+recall else 0.0
        per.append({'label':label,'precision':precision,'recall':recall,'f1':f1,'support':support}); macro.append(f1); weighted+=f1*support
    return {'accuracy':correct/total if total else 0.0,'macro_f1':sum(macro)/len(labels),'weighted_f1':weighted/total if total else 0.0,'per_label':per,'confusion_matrix':m,'labels':labels}
def main():
    root=Path(__file__).resolve().parents[1]; p=root/'vlm_eval/anomaly_eval_input.csv'
    if not p.exists(): p=root/'vlm_eval/anomaly_eval_input_template.csv'; print('주의: 템플릿 파일을 읽습니다. 실제 검증은 anomaly_eval_input.csv를 만들어 실행하세요.')
    yt=[]; yp=[]
    with open(p,newline='',encoding='utf-8') as fp:
        for row in csv.DictReader(fp):
            t=row['true_class'].strip(); pr=row['pred_class'].strip()
            if t not in CLASSES or pr not in CLASSES: raise ValueError(f'unknown class: true={t}, pred={pr}')
            yt.append(t); yp.append(pr)
    class_report=report(yt,yp,CLASSES); risk_report=report([RISK_MAP[x] for x in yt],[RISK_MAP[x] for x in yp],RISKS)
    out=root/'outputs/metrics'; out.mkdir(parents=True,exist_ok=True)
    (out/'vlm_classification_metrics.json').write_text(json.dumps({'class_report':class_report,'risk_report':risk_report},ensure_ascii=False,indent=2),encoding='utf-8')
    with open(out/'vlm_per_class_metrics.csv','w',newline='',encoding='utf-8') as fp:
        w=csv.DictWriter(fp,fieldnames=['label','precision','recall','f1','support']); w.writeheader(); w.writerows(class_report['per_label'])
    print(json.dumps({'class_report':class_report,'risk_report':risk_report},ensure_ascii=False,indent=2))
if __name__=='__main__': main()
