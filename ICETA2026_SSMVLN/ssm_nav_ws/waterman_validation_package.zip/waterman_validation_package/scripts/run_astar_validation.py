# A* validation rerun script
import csv, json, heapq
from pathlib import Path
import numpy as np
from PIL import Image, ImageDraw
START=(14,0)
def astar(grid,start,target):
    R,C=grid.shape
    def h(p): return abs(p[0]-target[0])+abs(p[1]-target[1])
    pq=[(h(start),0,start)]; came={start:None}; g={start:0}; expanded=0
    for dr,dc in [(-1,0),(1,0),(0,-1),(0,1)]: pass
    dirs=[(-1,0),(1,0),(0,-1),(0,1)]
    while pq:
        _,cost,cur=heapq.heappop(pq)
        if cost != g[cur]: continue
        expanded += 1
        if cur==target:
            path=[]; p=cur
            while p is not None:
                path.append(p); p=came[p]
            return path[::-1], expanded
        for dr,dc in dirs:
            nr,nc=cur[0]+dr,cur[1]+dc
            if 0<=nr<R and 0<=nc<C and grid[nr,nc]!=1:
                nb=(nr,nc); ng=cost+1
                if ng<g.get(nb,10**9):
                    g[nb]=ng; came[nb]=cur; heapq.heappush(pq,(ng+h(nb),ng,nb))
    return None, expanded
def draw_path(grid,path,start,target,outpath):
    cell=32; margin=36; R,C=grid.shape
    img=Image.new('RGB',(C*cell,R*cell+margin),'white'); d=ImageDraw.Draw(img)
    for r in range(R):
        for c in range(C):
            col=(255,255,255) if grid[r,c]==0 else (35,35,35) if grid[r,c]==1 else (40,190,70)
            if path and (r,c) in set(path): col=(80,145,235)
            if (r,c)==start: col=(255,200,30)
            if (r,c)==target: col=(40,190,70)
            x0,y0=c*cell,r*cell+margin; d.rectangle([x0,y0,x0+cell,y0+cell],fill=col,outline=(180,180,180))
    if path:
        d.line([(c*cell+cell//2,r*cell+margin+cell//2) for r,c in path],fill=(20,80,180),width=4)
    for label,p in [('S',start),('G',target)]:
        r,c=p; d.text((c*cell+cell//2-4,r*cell+margin+cell//2-6),label,fill=(0,0,0))
    d.text((10,10),f'{outpath.stem.replace("_astar_success","")} A* SUCCESS | moves={len(path)-1 if path else "NA"}',fill=(0,0,0)); img.save(outpath)
def main():
    root=Path(__file__).resolve().parents[1]; maps=root/'maps/grid_unseen'; img_dir=root/'outputs/astar_success_images'; met=root/'outputs/metrics'
    img_dir.mkdir(parents=True,exist_ok=True); met.mkdir(parents=True,exist_ok=True); rows=[]
    for f in sorted(maps.glob('*.csv')):
        grid=np.loadtxt(f,delimiter=',',dtype=int); target=tuple(map(int,np.argwhere(grid==2)[0])); path,expanded=astar(grid,START,target); moves=len(path)-1 if path else None
        rows.append({'map':f.stem,'success':int(path is not None),'start_r':START[0],'start_c':START[1],'target_r':target[0],'target_c':target[1],'astar_path_nodes':len(path) if path else 0,'astar_moves':moves if moves is not None else '', 'manhattan_distance':abs(START[0]-target[0])+abs(START[1]-target[1]),'expanded_nodes':expanded,'obstacle_count':int((grid==1).sum()),'free_count':int((grid==0).sum())})
        draw_path(grid,path,START,target,img_dir/f'{f.stem}_astar_success.png')
    with open(met/'astar_unseen_metrics.csv','w',newline='',encoding='utf-8') as fp:
        w=csv.DictWriter(fp,fieldnames=list(rows[0].keys())); w.writeheader(); w.writerows(rows)
    moves=[r['astar_moves'] for r in rows if r['success']]
    summary={'algorithm':'A*','map_condition':'known grid map','map_count':len(rows),'success_count':sum(r['success'] for r in rows),'success_rate':sum(r['success'] for r in rows)/len(rows),'average_moves':float(np.mean(moves)),'min_moves':int(np.min(moves)),'max_moves':int(np.max(moves)),'average_expanded_nodes':float(np.mean([r['expanded_nodes'] for r in rows])),'average_obstacle_count':float(np.mean([r['obstacle_count'] for r in rows]))}
    (met/'astar_summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8'); print(json.dumps(summary,ensure_ascii=False,indent=2))
if __name__=='__main__': main()
